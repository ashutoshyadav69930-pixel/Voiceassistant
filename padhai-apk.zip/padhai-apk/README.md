# Padhai App (APK)
GitHub par daalne ke baad APK apne aap banta hai.
1. Is folder ki sari files ek naye GitHub repo mein upload karein (.github folder samet).
2. Repo ke Actions tab mein "Build APK" chalne dein (3-5 minute).
3. Pura hone par us run ke neeche Artifacts se padhai-apk download karein.
4. Zip kholkar app-debug.apk phone mein install karein (Unknown sources allow karein).
