package com.example.voiceassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.net.Uri
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply {
            text = "बटन दबाकर बोलिए\n(जैसे: \"व्हाट्सऐप खोलो\")"
            textSize = 20f; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
        }
        val speakBtn = Button(this).apply { text = "🎤 बोलिए"; textSize = 22f }
        val accBtn = Button(this).apply { text = "Accessibility चालू करें" }

        val bgBtn = Button(this).apply { text = "▶ हमेशा सुनना चालू करें" }
        val batBtn = Button(this).apply { text = "बैटरी रोक हटाएँ (ज़रूरी)" }
        root.addView(status); root.addView(speakBtn); root.addView(bgBtn)
        root.addView(accBtn); root.addView(batBtn)

        bgBtn.setOnClickListener {
            if (ListenService.running) {
                stopService(Intent(this, ListenService::class.java))
                bgBtn.text = "▶ हमेशा सुनना चालू करें"
            } else {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this,
                        arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
                } else {
                    ContextCompat.startForegroundService(this, Intent(this, ListenService::class.java))
                    bgBtn.text = "■ हमेशा सुनना बंद करें"
                    status.text = "अब बोलिए: \"${ListenService.WAKE_WORDS[0]} व्हाट्सऐप खोलो\""
                }
            }
        }
        batBtn.setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")))
            }
        }
        setContentView(root)

        tts = TextToSpeech(this, this)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(listener)

        speakBtn.setOnClickListener { startListening() }
        accBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        status.text = "सुन रहा हूँ…"
        recognizer.startListening(i)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: android.os.Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: return
            val reply = CommandHandler.handle(this@MainActivity, text)
            status.text = "आपने कहा: $text\n\n$reply"
            tts.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "r")
        }
        override fun onError(error: Int) { status.text = "समझ नहीं आया, फिर बोलिए (कोड $error)" }
        override fun onReadyForSpeech(p: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
    }

    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }

    override fun onDestroy() { recognizer.destroy(); tts.shutdown(); super.onDestroy() }
}
