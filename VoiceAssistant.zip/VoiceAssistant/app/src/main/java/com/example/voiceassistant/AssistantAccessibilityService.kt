package com.example.voiceassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AssistantAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AssistantAccessibilityService? = null
        @Volatile var waitingToSend = false
    }

    override fun onServiceConnected() { instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // WhatsApp चैट खुलने पर Send बटन अपने-आप दबाओ
        if (waitingToSend && event?.packageName == "com.whatsapp") {
            val root = rootInActiveWindow ?: return
            val btn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
                .firstOrNull()
                ?: root.findAccessibilityNodeInfosByText("Send").firstOrNull()
                ?: root.findAccessibilityNodeInfosByText("भेजें").firstOrNull()
            if (btn != null) {
                btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                waitingToSend = false
            }
        }
    }

    fun goBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun goHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun scroll(forward: Boolean) {
        val node = findScrollable(rootInActiveWindow) ?: return
        node.performAction(
            if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    private fun findScrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) findScrollable(n.getChild(i))?.let { return it }
        return null
    }
}
