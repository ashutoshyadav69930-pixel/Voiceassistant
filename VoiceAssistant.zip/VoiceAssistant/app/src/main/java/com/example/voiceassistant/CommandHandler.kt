package com.example.voiceassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

object CommandHandler {

    // हिंदी नाम -> अंग्रेज़ी नाम (ऐप के label से मिलाने के लिए)
    private val aliases = mapOf(
        "व्हाट्सऐप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "यूट्यूब" to "youtube", "क्रोम" to "chrome", "कैमरा" to "camera",
        "गैलरी" to "gallery", "फोटो" to "photos", "सेटिंग" to "settings",
        "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "मैप्स" to "maps",
        "जीमेल" to "gmail", "टेलीग्राम" to "telegram", "कैलकुलेटर" to "calculator"
    )
    private val openWords = listOf("खोलो", "खोलिए", "खोल", "चालू करो", "kholo", "open", "start")

    /** जवाब का टेक्स्ट लौटाता है */
    fun handle(baseCtx: Context, spoken: String): String {
        // Android 10+ में बैकग्राउंड से activity खोलना रोका जाता है; Accessibility service का context इससे छूट पाता है
        val ctx: Context = AssistantAccessibilityService.instance ?: baseCtx
        val cmd = spoken.lowercase().trim()
        val acc = AssistantAccessibilityService.instance

        // 1) WhatsApp मैसेज: "9876543210 को नमस्ते भेजो"
        Regex("""(\d{10,12}).*?(?:को|ko)\s+(.+?)\s+(?:भेजो|भेज दो|bhejo|send)""").find(cmd)?.let {
            if (acc == null) return "पहले Accessibility सर्विस चालू करें"
            var num = it.groupValues[1]
            if (num.length == 10) num = "91$num"
            val text = it.groupValues[2]
            AssistantAccessibilityService.waitingToSend = true
            val i = Intent(Intent.ACTION_VIEW,
                Uri.parse("https://wa.me/$num?text=${Uri.encode(text)}"))
                .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return "$num को मैसेज भेज रहा हूँ"
        }

        // 2) सिस्टम एक्शन
        if (listOf("पीछे", "back", "वापस").any { it in cmd }) {
            return if (acc?.goBack() == true) "पीछे गया" else "Accessibility चालू करें"
        }
        if (listOf("होम", "home").any { it in cmd }) {
            return if (acc?.goHome() == true) "होम पर आ गया" else "Accessibility चालू करें"
        }
        if (listOf("नीचे", "scroll down", "स्क्रॉल").any { it in cmd }) {
            acc?.scroll(true); return "नीचे स्क्रॉल"
        }
        if (listOf("ऊपर", "scroll up").any { it in cmd }) {
            acc?.scroll(false); return "ऊपर स्क्रॉल"
        }
        if (cmd.contains("कैमरा") && openWords.any { it in cmd }) {
            ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "कैमरा खोल रहा हूँ"
        }

        // 3) कोई भी ऐप खोलो
        if (openWords.any { it in cmd }) {
            var name = cmd
            openWords.forEach { name = name.replace(it, "") }
            listOf("ऐप", "app", "को", "ko").forEach { name = name.replace(it, "") }
            name = name.trim()
            aliases.forEach { (hi, en) -> if (hi in name) name = en }
            return if (openApp(ctx, name)) "$name खोल रहा हूँ" else "'$name' ऐप नहीं मिला"
        }
        return "समझ नहीं आया: $spoken"
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        if (name.isBlank()) return false
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        } ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
