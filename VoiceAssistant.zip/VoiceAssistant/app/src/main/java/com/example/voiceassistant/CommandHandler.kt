package com.example.voiceassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

/** हल्का वर्ज़न: Accessibility के बिना. ऐप खोलना, कैमरा, डायल, WhatsApp चैट (Send खुद दबाना होगा) */
object CommandHandler {

    private val aliases = mapOf(
        "व्हाट्सऐप" to "whatsapp", "व्हाट्सएप" to "whatsapp", "वॉट्सऐप" to "whatsapp",
        "यूट्यूब" to "youtube", "क्रोम" to "chrome", "कैमरा" to "camera",
        "गैलरी" to "gallery", "फोटो" to "photos", "सेटिंग" to "settings",
        "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook", "मैप्स" to "maps",
        "जीमेल" to "gmail", "टेलीग्राम" to "telegram", "कैलकुलेटर" to "calculator"
    )
    private val openWords = listOf("खोलो", "खोलिए", "खोल", "चालू करो", "kholo", "open", "start")

    fun handle(ctx: Context, spoken: String): String {
        val cmd = spoken.lowercase().trim()

        // WhatsApp: "9876543210 को नमस्ते भेजो" -> चैट खुलेगी, मैसेज लिखा होगा
        Regex("""(\d{10,12}).*?(?:को|ko)\s+(.+?)\s+(?:भेजो|भेज दो|bhejo|send)""").find(cmd)?.let {
            var num = it.groupValues[1]
            if (num.length == 10) num = "91$num"
            val text = it.groupValues[2]
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num?text=${Uri.encode(text)}"))
                    .setPackage("com.whatsapp").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "चैट खोल दी, भेजें बटन दबाइए"
        }

        // कॉल (डायल स्क्रीन खुलेगी): "9876543210 को कॉल करो"
        Regex("""(\d{10,12}).*?(?:कॉल|call|फोन)""").find(cmd)?.let {
            ctx.startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:${it.groupValues[1]}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "डायल स्क्रीन खोल दी"
        }

        if (cmd.contains("कैमरा") && openWords.any { it in cmd }) {
            ctx.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "कैमरा खोल रहा हूँ"
        }

        if (openWords.any { it in cmd }) {
            var name = cmd
            openWords.forEach { name = name.replace(it, "") }
            listOf("ऐप", "app", "को", "ko").forEach { name = name.replace(it, "") }
            name = name.trim()
            aliases.forEach { (hi, en) -> if (hi in name) name = en }
            return if (openApp(ctx, name)) "$name खोल रहा हूँ" else "'$name' ऐप नहीं मिला"
        }
        return "समझ नहीं आया: $spoken"
    }

    private fun openApp(ctx: Context, name: String): Boolean {
        if (name.isBlank()) return false
        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        } ?: return false
        val i = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
