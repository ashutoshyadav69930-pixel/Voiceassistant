package com.example.voiceassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

/** हमेशा बैकग्राउंड में सुनने वाली सर्विस (स्क्रीन ऑफ में भी) */
class ListenService : Service(), TextToSpeech.OnInitListener {

    companion object {
        // बोलने की शुरुआत में यह शब्द बोलना होगा, जैसे: "जार्विस व्हाट्सऐप खोलो"
        val WAKE_WORDS = listOf("जार्विस", "जारविस", "जर्विस", "jarvis", "assistant", "असिस्टेंट")
        var running = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        tts = TextToSpeech(this, this)
        startForegroundNotification()
        handler.post { startRecognizer() }
    }

    override fun onInit(s: Int) { if (s == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN") }

    private fun startForegroundNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("listen", "आवाज़ असिस्टेंट", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "listen")
            .setContentTitle("असिस्टेंट सुन रहा है")
            .setContentText("\"${WAKE_WORDS[0]}\" बोलकर कमांड दें")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun startRecognizer() {
        if (!running) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val text = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text != null) process(text)
                    restart(300)
                }
                override fun onError(error: Int) {
                    // चुप्पी/नो-मैच पर बस दोबारा सुनना शुरू
                    restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    private fun restart(delay: Long) { handler.postDelayed({ startRecognizer() }, delay) }

    private fun process(text: String) {
        val lower = text.lowercase()
        val wake = WAKE_WORDS.firstOrNull { lower.contains(it) } ?: return   // वेक-वर्ड नहीं तो ignore
        val command = lower.substringAfter(wake).trim()
        if (command.isEmpty()) { speak("जी, बोलिए"); return }

        wakeScreen()
        // स्क्रीन जागने का थोड़ा इंतज़ार, फिर कमांड
        handler.postDelayed({
            val reply = CommandHandler.handle(this, command)
            speak(reply)
        }, 700)
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "voiceassistant:wake"
        ).acquire(8000)
    }

    private fun speak(t: String) = tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "r")

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); tts.shutdown()
        super.onDestroy()
    }
}
